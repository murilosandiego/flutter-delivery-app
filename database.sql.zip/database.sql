--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    slug character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: components_user_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.components_user_addresses (
    id integer NOT NULL,
    place character varying(255) NOT NULL,
    number character varying(255) NOT NULL,
    district character varying(255) NOT NULL,
    latitude double precision,
    longitude double precision,
    "default" boolean,
    zip_code character varying(255) NOT NULL,
    state character varying(255) NOT NULL,
    city character varying(255) NOT NULL,
    complement character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.components_user_addresses OWNER TO postgres;

--
-- Name: components_user_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.components_user_addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.components_user_addresses_id_seq OWNER TO postgres;

--
-- Name: components_user_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.components_user_addresses_id_seq OWNED BY public.components_user_addresses.id;


--
-- Name: core_store; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_store (
    id integer NOT NULL,
    key character varying(255),
    value text,
    type character varying(255),
    environment character varying(255),
    tag character varying(255)
);


ALTER TABLE public.core_store OWNER TO postgres;

--
-- Name: core_store_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_store_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_store_id_seq OWNER TO postgres;

--
-- Name: core_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_store_id_seq OWNED BY public.core_store.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    product integer,
    quantity integer NOT NULL,
    price numeric(10,2) NOT NULL,
    comments text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    price_unit numeric(10,2) NOT NULL,
    product_name character varying(255) NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_items_id_seq OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: order_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_statuses (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    sequence integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.order_statuses OWNER TO postgres;

--
-- Name: order_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_statuses_id_seq OWNER TO postgres;

--
-- Name: order_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_statuses_id_seq OWNED BY public.order_statuses.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    store integer,
    "user" integer,
    comments text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    payment_type integer,
    "deliveryFee" numeric(10,2),
    total numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    order_status integer,
    delivery boolean NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders__order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders__order_items (
    id integer NOT NULL,
    order_id integer,
    "order-item_id" integer
);


ALTER TABLE public.orders__order_items OWNER TO postgres;

--
-- Name: orders__order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders__order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders__order_items_id_seq OWNER TO postgres;

--
-- Name: orders__order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders__order_items_id_seq OWNED BY public.orders__order_items.id;


--
-- Name: orders_components; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders_components (
    id integer NOT NULL,
    field character varying(255) NOT NULL,
    "order" integer NOT NULL,
    component_type character varying(255) NOT NULL,
    component_id integer NOT NULL,
    order_id integer NOT NULL
);


ALTER TABLE public.orders_components OWNER TO postgres;

--
-- Name: orders_components_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_components_id_seq OWNER TO postgres;

--
-- Name: orders_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_components_id_seq OWNED BY public.orders_components.id;


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payment_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    receive character varying(255) NOT NULL
);


ALTER TABLE public.payment_types OWNER TO postgres;

--
-- Name: payment_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_types_id_seq OWNER TO postgres;

--
-- Name: payment_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_types_id_seq OWNED BY public.payment_types.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    category integer,
    store integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: store_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    slug character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.store_types OWNER TO postgres;

--
-- Name: store_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_types_id_seq OWNER TO postgres;

--
-- Name: store_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_types_id_seq OWNED BY public.store_types.id;


--
-- Name: stores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stores (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    "startTime" time without time zone,
    "endTime" time without time zone,
    slug character varying(255) NOT NULL,
    "deliveryFee" numeric(10,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    store_type integer,
    category integer,
    created_by integer,
    updated_by integer
);


ALTER TABLE public.stores OWNER TO postgres;

--
-- Name: stores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stores_id_seq OWNER TO postgres;

--
-- Name: stores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stores_id_seq OWNED BY public.stores.id;


--
-- Name: strapi_administrator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strapi_administrator (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    "resetPasswordToken" character varying(255),
    blocked boolean,
    firstname character varying(255),
    lastname character varying(255),
    "registrationToken" character varying(255),
    "isActive" boolean
);


ALTER TABLE public.strapi_administrator OWNER TO postgres;

--
-- Name: strapi_administrator_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.strapi_administrator_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_administrator_id_seq OWNER TO postgres;

--
-- Name: strapi_administrator_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.strapi_administrator_id_seq OWNED BY public.strapi_administrator.id;


--
-- Name: strapi_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strapi_permission (
    id integer NOT NULL,
    action character varying(255) NOT NULL,
    subject character varying(255),
    fields jsonb,
    conditions jsonb,
    role integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.strapi_permission OWNER TO postgres;

--
-- Name: strapi_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.strapi_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_permission_id_seq OWNER TO postgres;

--
-- Name: strapi_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.strapi_permission_id_seq OWNED BY public.strapi_permission.id;


--
-- Name: strapi_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strapi_role (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.strapi_role OWNER TO postgres;

--
-- Name: strapi_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.strapi_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_role_id_seq OWNER TO postgres;

--
-- Name: strapi_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.strapi_role_id_seq OWNED BY public.strapi_role.id;


--
-- Name: strapi_users_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strapi_users_roles (
    id integer NOT NULL,
    user_id integer,
    role_id integer
);


ALTER TABLE public.strapi_users_roles OWNER TO postgres;

--
-- Name: strapi_users_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.strapi_users_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_users_roles_id_seq OWNER TO postgres;

--
-- Name: strapi_users_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.strapi_users_roles_id_seq OWNED BY public.strapi_users_roles.id;


--
-- Name: strapi_webhooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strapi_webhooks (
    id integer NOT NULL,
    name character varying(255),
    url text,
    headers jsonb,
    events jsonb,
    enabled boolean
);


ALTER TABLE public.strapi_webhooks OWNER TO postgres;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.strapi_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_webhooks_id_seq OWNER TO postgres;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.strapi_webhooks_id_seq OWNED BY public.strapi_webhooks.id;


--
-- Name: upload_file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.upload_file (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "alternativeText" character varying(255),
    caption character varying(255),
    width integer,
    height integer,
    formats jsonb,
    hash character varying(255) NOT NULL,
    ext character varying(255),
    mime character varying(255) NOT NULL,
    size numeric(10,2) NOT NULL,
    url character varying(255) NOT NULL,
    "previewUrl" character varying(255),
    provider character varying(255) NOT NULL,
    provider_metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer
);


ALTER TABLE public.upload_file OWNER TO postgres;

--
-- Name: upload_file_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.upload_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.upload_file_id_seq OWNER TO postgres;

--
-- Name: upload_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.upload_file_id_seq OWNED BY public.upload_file.id;


--
-- Name: upload_file_morph; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.upload_file_morph (
    id integer NOT NULL,
    upload_file_id integer,
    related_id integer,
    related_type text,
    field text,
    "order" integer
);


ALTER TABLE public.upload_file_morph OWNER TO postgres;

--
-- Name: upload_file_morph_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.upload_file_morph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.upload_file_morph_id_seq OWNER TO postgres;

--
-- Name: upload_file_morph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.upload_file_morph_id_seq OWNED BY public.upload_file_morph.id;


--
-- Name: users-permissions_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."users-permissions_permission" (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    controller character varying(255) NOT NULL,
    action character varying(255) NOT NULL,
    enabled boolean NOT NULL,
    policy character varying(255),
    role integer,
    created_by integer,
    updated_by integer
);


ALTER TABLE public."users-permissions_permission" OWNER TO postgres;

--
-- Name: users-permissions_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."users-permissions_permission_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."users-permissions_permission_id_seq" OWNER TO postgres;

--
-- Name: users-permissions_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."users-permissions_permission_id_seq" OWNED BY public."users-permissions_permission".id;


--
-- Name: users-permissions_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."users-permissions_role" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255),
    created_by integer,
    updated_by integer
);


ALTER TABLE public."users-permissions_role" OWNER TO postgres;

--
-- Name: users-permissions_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."users-permissions_role_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."users-permissions_role_id_seq" OWNER TO postgres;

--
-- Name: users-permissions_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."users-permissions_role_id_seq" OWNED BY public."users-permissions_role".id;


--
-- Name: users-permissions_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."users-permissions_user" (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    provider character varying(255),
    password character varying(255),
    "resetPasswordToken" character varying(255),
    confirmed boolean,
    blocked boolean,
    role integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    store integer,
    name character varying(255) NOT NULL,
    created_by integer,
    updated_by integer,
    phone character varying(255),
    cpf character varying(255)
);


ALTER TABLE public."users-permissions_user" OWNER TO postgres;

--
-- Name: users-permissions_user_components; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."users-permissions_user_components" (
    id integer NOT NULL,
    field character varying(255) NOT NULL,
    "order" integer NOT NULL,
    component_type character varying(255) NOT NULL,
    component_id integer NOT NULL,
    "users-permissions_user_id" integer NOT NULL
);


ALTER TABLE public."users-permissions_user_components" OWNER TO postgres;

--
-- Name: users-permissions_user_components_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."users-permissions_user_components_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."users-permissions_user_components_id_seq" OWNER TO postgres;

--
-- Name: users-permissions_user_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."users-permissions_user_components_id_seq" OWNED BY public."users-permissions_user_components".id;


--
-- Name: users-permissions_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."users-permissions_user_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."users-permissions_user_id_seq" OWNER TO postgres;

--
-- Name: users-permissions_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."users-permissions_user_id_seq" OWNED BY public."users-permissions_user".id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: components_user_addresses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.components_user_addresses ALTER COLUMN id SET DEFAULT nextval('public.components_user_addresses_id_seq'::regclass);


--
-- Name: core_store id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_store ALTER COLUMN id SET DEFAULT nextval('public.core_store_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: order_statuses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_statuses ALTER COLUMN id SET DEFAULT nextval('public.order_statuses_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: orders__order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders__order_items ALTER COLUMN id SET DEFAULT nextval('public.orders__order_items_id_seq'::regclass);


--
-- Name: orders_components id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders_components ALTER COLUMN id SET DEFAULT nextval('public.orders_components_id_seq'::regclass);


--
-- Name: payment_types id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_types ALTER COLUMN id SET DEFAULT nextval('public.payment_types_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: store_types id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_types ALTER COLUMN id SET DEFAULT nextval('public.store_types_id_seq'::regclass);


--
-- Name: stores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores ALTER COLUMN id SET DEFAULT nextval('public.stores_id_seq'::regclass);


--
-- Name: strapi_administrator id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_administrator ALTER COLUMN id SET DEFAULT nextval('public.strapi_administrator_id_seq'::regclass);


--
-- Name: strapi_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_permission ALTER COLUMN id SET DEFAULT nextval('public.strapi_permission_id_seq'::regclass);


--
-- Name: strapi_role id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_role ALTER COLUMN id SET DEFAULT nextval('public.strapi_role_id_seq'::regclass);


--
-- Name: strapi_users_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_users_roles ALTER COLUMN id SET DEFAULT nextval('public.strapi_users_roles_id_seq'::regclass);


--
-- Name: strapi_webhooks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_webhooks ALTER COLUMN id SET DEFAULT nextval('public.strapi_webhooks_id_seq'::regclass);


--
-- Name: upload_file id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upload_file ALTER COLUMN id SET DEFAULT nextval('public.upload_file_id_seq'::regclass);


--
-- Name: upload_file_morph id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upload_file_morph ALTER COLUMN id SET DEFAULT nextval('public.upload_file_morph_id_seq'::regclass);


--
-- Name: users-permissions_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_permission" ALTER COLUMN id SET DEFAULT nextval('public."users-permissions_permission_id_seq"'::regclass);


--
-- Name: users-permissions_role id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_role" ALTER COLUMN id SET DEFAULT nextval('public."users-permissions_role_id_seq"'::regclass);


--
-- Name: users-permissions_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_user" ALTER COLUMN id SET DEFAULT nextval('public."users-permissions_user_id_seq"'::regclass);


--
-- Name: users-permissions_user_components id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_user_components" ALTER COLUMN id SET DEFAULT nextval('public."users-permissions_user_components_id_seq"'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, slug, created_at, updated_at, created_by, updated_by) FROM stdin;
1	Pizza	\N	pizza	2020-06-25 21:28:02.332-03	2020-06-25 21:28:02.332-03	\N	\N
2	Lanche	\N	lanche	2020-06-25 21:28:36.447-03	2020-06-25 21:28:36.447-03	\N	\N
3	Bebidas	\N	bebidas	2020-06-25 21:28:51.355-03	2020-06-25 21:28:51.355-03	\N	\N
4	Açai	\N	acai	2020-06-25 21:29:07.861-03	2020-06-25 21:29:07.861-03	\N	\N
5	Doces e Bolos	\N	doces-e-bolos	2020-06-25 21:29:37.639-03	2020-06-25 21:29:37.639-03	\N	\N
6	Massas	\N	massas	2020-06-25 21:36:44.384-03	2020-06-25 21:36:44.384-03	\N	\N
\.


--
-- Data for Name: components_user_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.components_user_addresses (id, place, number, district, latitude, longitude, "default", zip_code, state, city, complement, name) FROM stdin;
21	Rua Antônio de Godói 88	1	Centro	\N	\N	\N	01.034-902	SP	São Paulo		casa
\.


--
-- Data for Name: core_store; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_store (id, key, value, type, environment, tag) FROM stdin;
2	db_model_core_store	{"key":{"type":"string"},"value":{"type":"text"},"type":{"type":"string"},"environment":{"type":"string"},"tag":{"type":"string"}}	object	\N	\N
4	db_model_strapi_webhooks	{"name":{"type":"string"},"url":{"type":"text"},"headers":{"type":"json"},"events":{"type":"json"},"enabled":{"type":"boolean"}}	object	\N	\N
8	db_model_upload_file_morph	{"upload_file_id":{"type":"integer"},"related_id":{"type":"integer"},"related_type":{"type":"text"},"field":{"type":"text"},"order":{"type":"integer"}}	object	\N	\N
9	plugin_users-permissions_grant	{"email":{"enabled":true,"icon":"envelope"},"discord":{"enabled":false,"icon":"discord","key":"","secret":"","callback":"/auth/discord/callback","scope":["identify","email"]},"facebook":{"enabled":false,"icon":"facebook-square","key":"","secret":"","callback":"/auth/facebook/callback","scope":["email"]},"google":{"enabled":false,"icon":"google","key":"","secret":"","callback":"/auth/google/callback","scope":["email"]},"github":{"enabled":false,"icon":"github","key":"","secret":"","callback":"/auth/github/callback","scope":["user","user:email"]},"microsoft":{"enabled":false,"icon":"windows","key":"","secret":"","callback":"/auth/microsoft/callback","scope":["user.read"]},"twitter":{"enabled":false,"icon":"twitter","key":"","secret":"","callback":"/auth/twitter/callback"},"instagram":{"enabled":false,"icon":"instagram","key":"","secret":"","callback":"/auth/instagram/callback"},"vk":{"enabled":false,"icon":"vk","key":"","secret":"","callback":"/auth/vk/callback","scope":["email"]},"twitch":{"enabled":false,"icon":"twitch","key":"","secret":"","callback":"/auth/twitch/callback","scope":["user:read:email"]}}	object		
10	plugin_upload_settings	{"sizeOptimization":true,"responsiveDimensions":true}	object	development	
11	plugin_content_manager_configuration_content_types::plugins::users-permissions.permission	{"uid":"plugins::users-permissions.permission","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"type","defaultSortBy":"type","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"controller":{"edit":{"label":"Controller","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Controller","searchable":true,"sortable":true}},"action":{"edit":{"label":"Action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Action","searchable":true,"sortable":true}},"enabled":{"edit":{"label":"Enabled","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Enabled","searchable":true,"sortable":true}},"policy":{"edit":{"label":"Policy","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Policy","searchable":true,"sortable":true}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}}},"layouts":{"list":["id","type","controller","action"],"editRelations":["role"],"edit":[[{"name":"type","size":6},{"name":"controller","size":6}],[{"name":"action","size":6},{"name":"enabled","size":4}],[{"name":"policy","size":6}]]}}	object		
13	plugin_content_manager_configuration_content_types::plugins::upload.file	{"uid":"plugins::upload.file","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"AlternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"AlternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"Caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Caption","searchable":true,"sortable":true}},"width":{"edit":{"label":"Width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Width","searchable":true,"sortable":true}},"height":{"edit":{"label":"Height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"Formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"Hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"Ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"Mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"Size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Size","searchable":true,"sortable":true}},"url":{"edit":{"label":"Url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"PreviewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"PreviewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"Provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"Provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Provider_metadata","searchable":false,"sortable":false}},"related":{"edit":{"label":"Related","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Related","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","alternativeText","caption"],"editRelations":["related"],"edit":[[{"name":"name","size":6},{"name":"alternativeText","size":6}],[{"name":"caption","size":6},{"name":"width","size":4}],[{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"hash","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"previewUrl","size":6}],[{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}]]}}	object		
6	db_model_strapi_administrator	{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"required":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"blocked":{"type":"boolean","default":false,"configurable":false}}	object	\N	\N
3	db_model_upload_file	{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"collection":"*","filter":"field","configurable":false},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
12	plugin_content_manager_configuration_content_types::plugins::users-permissions.role	{"uid":"plugins::users-permissions.role","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"Permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"type"},"list":{"label":"Permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"Users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Users","searchable":false,"sortable":false}}},"layouts":{"list":["id","name","description","type"],"editRelations":["permissions","users"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6}]]}}	object		
16	plugin_users-permissions_email	{"reset_password":{"display":"Email.template.reset_password","icon":"sync","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\\n\\n<p>But don’t worry! You can use the following link to reset your password:</p>\\n<p><%= URL %>?code=<%= TOKEN %></p>\\n\\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\\n\\n<p>You have to confirm your email address. Please click on the link below.</p>\\n\\n<p><%= URL %>?confirmation=<%= CODE %></p>\\n\\n<p>Thanks.</p>"}}}	object		
17	plugin_users-permissions_advanced	{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_confirmation_redirection":"/admin/admin","email_reset_password":"/admin/admin","default_role":"authenticated"}	object		
40	plugin_content_manager_configuration_content_types::application::order.order	{"uid":"application::order.order","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"store":{"edit":{"label":"Store","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Store","searchable":false,"sortable":false}},"payment_type":{"edit":{"label":"Payment_type","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Payment_type","searchable":false,"sortable":false}},"total":{"edit":{"label":"Total","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Total","searchable":true,"sortable":true}},"user":{"edit":{"label":"User","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"User","searchable":false,"sortable":false}},"comments":{"edit":{"label":"Comments","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Comments","searchable":true,"sortable":true}},"order_items":{"edit":{"label":"Order_items","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Order_items","searchable":false,"sortable":false}},"deliveryFee":{"edit":{"label":"DeliveryFee","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"DeliveryFee","searchable":true,"sortable":true}},"subtotal":{"edit":{"label":"Subtotal","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Subtotal","searchable":true,"sortable":true}},"order_status":{"edit":{"label":"Order_status","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Order_status","searchable":false,"sortable":false}},"delivery":{"edit":{"label":"Delivery","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Delivery","searchable":true,"sortable":true}},"address":{"edit":{"label":"Address","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Address","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","comments","total","delivery"],"edit":[[{"name":"comments","size":6},{"name":"deliveryFee","size":4}],[{"name":"total","size":4},{"name":"subtotal","size":4},{"name":"delivery","size":4}],[{"name":"address","size":12}]],"editRelations":["store","user","order_items","payment_type","order_status"]}}	object		
7	db_model_users-permissions_user	{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"model":"role","via":"users","plugin":"users-permissions","configurable":false},"store":{"model":"store","via":"users"},"name":{"type":"string","required":true},"orders":{"collection":"order","via":"user","isVirtual":true},"adresses":{"type":"component","repeatable":true,"component":"user.address"},"phone":{"type":"string","unique":true},"cpf":{"type":"string","required":false,"unique":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
18	db_model_stores	{"name":{"type":"string","required":true},"description":{"type":"text"},"logo":{"model":"file","via":"related","allowedTypes":["images"],"plugin":"upload","required":true},"cover":{"model":"file","via":"related","allowedTypes":["images","files","videos"],"plugin":"upload","required":false},"startTime":{"type":"time"},"endTime":{"type":"time"},"slug":{"type":"uid","targetField":"name","required":true},"deliveryFee":{"type":"decimal"},"users":{"via":"store","plugin":"users-permissions","collection":"user","isVirtual":true},"products":{"via":"store","collection":"product","isVirtual":true},"category":{"via":"stores","model":"category"},"orders":{"via":"store","collection":"order","isVirtual":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
15	plugin_content_manager_configuration_content_types::plugins::users-permissions.user	{"uid":"plugins::users-permissions.user","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"username":{"edit":{"label":"Username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Username","searchable":true,"sortable":true}},"email":{"edit":{"label":"Email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"Provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"Password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"ResetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"ResetPasswordToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"Confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"Blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}},"store":{"edit":{"label":"Store","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Store","searchable":false,"sortable":false}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"orders":{"edit":{"label":"Orders","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Orders","searchable":false,"sortable":false}},"adresses":{"edit":{"label":"Adresses","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Adresses","searchable":false,"sortable":false}},"phone":{"edit":{"label":"Phone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Phone","searchable":true,"sortable":true}},"cpf":{"edit":{"label":"Cpf","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Cpf","searchable":true,"sortable":true}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"name","size":6},{"name":"username","size":6}],[{"name":"email","size":6},{"name":"password","size":6}],[{"name":"confirmed","size":4},{"name":"blocked","size":4}],[{"name":"adresses","size":12}],[{"name":"phone","size":6},{"name":"cpf","size":6}]],"editRelations":["role","store","orders"]}}	object		
19	plugin_content_manager_configuration_content_types::application::store.store	{"uid":"application::store.store","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"logo":{"edit":{"label":"Logo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Logo","searchable":false,"sortable":false}},"cover":{"edit":{"label":"Cover","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Cover","searchable":false,"sortable":false}},"startTime":{"edit":{"label":"StartTime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"StartTime","searchable":true,"sortable":true}},"endTime":{"edit":{"label":"EndTime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"EndTime","searchable":true,"sortable":true}},"slug":{"edit":{"label":"Slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Slug","searchable":true,"sortable":true}},"deliveryFee":{"edit":{"label":"DeliveryFee","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"DeliveryFee","searchable":true,"sortable":true}},"users":{"edit":{"label":"Users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Users","searchable":false,"sortable":false}},"products":{"edit":{"label":"Products","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Products","searchable":false,"sortable":false}},"category":{"edit":{"label":"Category","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Category","searchable":false,"sortable":false}},"orders":{"edit":{"label":"Orders","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Orders","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","logo"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"logo","size":6},{"name":"cover","size":6}],[{"name":"startTime","size":4},{"name":"endTime","size":4}],[{"name":"slug","size":6},{"name":"deliveryFee","size":4}]],"editRelations":["users","products","category","orders"]}}	object		
20	db_model_store_types	{"name":{"type":"string","required":true},"description":{"type":"text"},"slug":{"type":"uid","targetField":"name","required":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
22	db_model_categories	{"name":{"type":"string","required":true,"minLength":3},"description":{"type":"text"},"photo":{"model":"file","via":"related","allowedTypes":["images"],"plugin":"upload","required":true},"slug":{"type":"uid","targetField":"name","required":true},"stores":{"collection":"store","via":"category","isVirtual":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
24	db_model_products	{"name":{"type":"string","required":true},"description":{"type":"text"},"price":{"type":"decimal","required":true},"photo":{"model":"file","via":"related","allowedTypes":["images","files","videos"],"plugin":"upload","required":false},"store":{"model":"store","via":"products"},"order_items":{"via":"product","collection":"order-item","isVirtual":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
26	plugin_documentation_config	{"restrictedAccess":false}	object		
25	plugin_content_manager_configuration_content_types::application::product.product	{"uid":"application::product.product","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"price":{"edit":{"label":"Price","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Price","searchable":true,"sortable":true}},"photo":{"edit":{"label":"Photo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Photo","searchable":false,"sortable":false}},"store":{"edit":{"label":"Store","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Store","searchable":false,"sortable":false}},"order_items":{"edit":{"label":"Order_items","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Order_items","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","price"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"price","size":4},{"name":"photo","size":6}]],"editRelations":["store","order_items"]}}	object		
42	plugin_content_manager_configuration_content_types::application::order-status.order-status	{"uid":"application::order-status.order-status","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"sequence":{"edit":{"label":"Sequence","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Sequence","searchable":true,"sortable":true}},"orders":{"edit":{"label":"Orders","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Orders","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","sequence"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"sequence","size":4}]],"editRelations":["orders"]}}	object		
38	db_model_orders	{"store":{"model":"store","via":"orders"},"payment_type":{"model":"payment-type","via":"orders"},"total":{"type":"decimal","required":true,"min":0},"user":{"via":"orders","plugin":"users-permissions","model":"user"},"comments":{"type":"text"},"order_items":{"collection":"order-item","attribute":"order-item","column":"id","isVirtual":true},"deliveryFee":{"type":"decimal"},"subtotal":{"type":"decimal","required":true,"min":0},"order_status":{"model":"order-status","via":"orders"},"delivery":{"type":"boolean","default":true,"required":true},"address":{"type":"component","repeatable":false,"component":"user.address"},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
23	plugin_content_manager_configuration_content_types::application::category.category	{"uid":"application::category.category","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"photo":{"edit":{"label":"Photo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Photo","searchable":false,"sortable":false}},"slug":{"edit":{"label":"Slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Slug","searchable":true,"sortable":true}},"stores":{"edit":{"label":"Stores","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Stores","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","photo"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"photo","size":6},{"name":"slug","size":6}]],"editRelations":["stores"]}}	object		
27	db_model_strapi_permission	{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"fields":{"type":"json","configurable":false,"required":false,"default":[]},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"model":"role","plugin":"admin"},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
28	db_model_strapi_role	{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"collection":"user","via":"roles","plugin":"admin","attribute":"user","column":"id","isVirtual":true},"permissions":{"configurable":false,"plugin":"admin","collection":"permission","via":"role","isVirtual":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
29	db_model_strapi_users_roles	{"user_id":{"type":"integer"},"role_id":{"type":"integer"}}	object	\N	\N
1	db_model_users-permissions_permission	{"type":{"type":"string","required":true,"configurable":false},"controller":{"type":"string","required":true,"configurable":false},"action":{"type":"string","required":true,"configurable":false},"enabled":{"type":"boolean","required":true,"configurable":false},"policy":{"type":"string","configurable":false},"role":{"model":"role","via":"permissions","plugin":"users-permissions","configurable":false}}	object	\N	\N
5	db_model_users-permissions_role	{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"collection":"permission","via":"role","plugin":"users-permissions","configurable":false,"isVirtual":true},"users":{"collection":"user","via":"role","configurable":false,"plugin":"users-permissions","isVirtual":true}}	object	\N	\N
33	plugin_content_manager_configuration_content_types::strapi::administrator	{"uid":"strapi::administrator","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"username":{"edit":{"label":"Username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Username","searchable":true,"sortable":true}},"email":{"edit":{"label":"Email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Email","searchable":true,"sortable":true}},"password":{"edit":{"label":"Password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"ResetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"ResetPasswordToken","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"Blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Blocked","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","blocked"],"editRelations":[],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"blocked","size":4}]]}}	object		
39	db_model_orders__order_items	{"order_id":{"type":"integer"},"order-item_id":{"type":"integer"}}	object	\N	\N
37	plugin_content_manager_configuration_content_types::application::order-item.order-item	{"uid":"application::order-item.order-item","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"product":{"edit":{"label":"Product","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Product","searchable":false,"sortable":false}},"quantity":{"edit":{"label":"Quantity","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Quantity","searchable":true,"sortable":true}},"price":{"edit":{"label":"Price","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Price","searchable":true,"sortable":true}},"comments":{"edit":{"label":"Comments","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Comments","searchable":true,"sortable":true}},"price_unit":{"edit":{"label":"Price_unit","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Price_unit","searchable":true,"sortable":true}},"product_name":{"edit":{"label":"Product_name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Product_name","searchable":true,"sortable":true}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","quantity","price","comments"],"edit":[[{"name":"quantity","size":4},{"name":"price","size":4}],[{"name":"comments","size":6},{"name":"price_unit","size":4}],[{"name":"product_name","size":6}]],"editRelations":["product"]}}	object		
41	db_model_order_statuses	{"name":{"type":"string","required":true},"description":{"type":"text"},"sequence":{"type":"integer","required":true,"unique":true,"min":0},"orders":{"via":"order_status","collection":"order","isVirtual":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
35	plugin_content_manager_configuration_content_types::application::payment-type.payment-type	{"uid":"application::payment-type.payment-type","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"slug":{"edit":{"label":"Slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Slug","searchable":true,"sortable":true}},"receive":{"edit":{"label":"Receive","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Receive","searchable":true,"sortable":true}},"orders":{"edit":{"label":"Orders","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Orders","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","slug","created_at"],"edit":[[{"name":"name","size":6},{"name":"slug","size":6}],[{"name":"receive","size":6}]],"editRelations":["orders"]}}	object		
34	db_model_payment_types	{"name":{"type":"string","required":true,"unique":true},"slug":{"type":"uid","targetField":"name"},"receive":{"type":"enumeration","enum":["App","Store"],"required":true,"default":"App"},"orders":{"via":"payment_type","collection":"order","isVirtual":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
36	db_model_order_items	{"product":{"model":"product","via":"order_items"},"quantity":{"type":"integer","required":true,"min":1},"price":{"type":"decimal","required":true,"min":0},"comments":{"type":"text"},"price_unit":{"type":"decimal","required":true,"min":0},"product_name":{"type":"string","required":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}	object	\N	\N
43	db_model_components_user_addresses	{"name":{"type":"string","required":true},"place":{"type":"string","required":true},"number":{"type":"string","required":true},"district":{"type":"string","required":true},"latitude":{"type":"float"},"longitude":{"type":"float"},"default":{"type":"boolean","default":false},"zip_code":{"type":"string","required":true},"state":{"type":"string","required":true},"city":{"type":"string","required":true},"complement":{"type":"string"}}	object	\N	\N
44	plugin_content_manager_configuration_components::user.address	{"uid":"user.address","isComponent":true,"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"place":{"edit":{"label":"Place","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Place","searchable":true,"sortable":true}},"number":{"edit":{"label":"Number","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Number","searchable":true,"sortable":true}},"district":{"edit":{"label":"District","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"District","searchable":true,"sortable":true}},"latitude":{"edit":{"label":"Latitude","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Latitude","searchable":true,"sortable":true}},"longitude":{"edit":{"label":"Longitude","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Longitude","searchable":true,"sortable":true}},"default":{"edit":{"label":"Default","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Default","searchable":true,"sortable":true}},"zip_code":{"edit":{"label":"Zip_code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Zip_code","searchable":true,"sortable":true}},"state":{"edit":{"label":"State","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"State","searchable":true,"sortable":true}},"city":{"edit":{"label":"City","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"City","searchable":true,"sortable":true}},"complement":{"edit":{"label":"Complement","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Complement","searchable":true,"sortable":true}}},"layouts":{"list":["id","place","number","name"],"edit":[[{"name":"place","size":6}],[{"name":"number","size":6},{"name":"district","size":6}],[{"name":"latitude","size":4},{"name":"longitude","size":4},{"name":"default","size":4}],[{"name":"zip_code","size":6},{"name":"state","size":6}],[{"name":"city","size":6},{"name":"complement","size":6}],[{"name":"name","size":6}]],"editRelations":[]}}	object		
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, product, quantity, price, comments, created_at, updated_at, price_unit, product_name) FROM stdin;
\.


--
-- Data for Name: order_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_statuses (id, name, description, sequence, created_at, updated_at) FROM stdin;
6	Entregue	Seu pedido foi entregue no endereço	4	2020-08-23 11:40:44.494-03	2020-08-23 12:45:20.104-03
5	Em transporte 	Seu pedido saiu para entrega	3	2020-08-23 11:39:43.63-03	2020-08-23 12:45:25.905-03
2	Confirmado	O estabelecimento está preparando seu pedido	2	2020-08-23 11:38:08.109-03	2020-08-23 12:45:30.721-03
1	Realizado	Seu pedido está sendo confirmado com o estabelecimento 	1	2020-08-23 11:37:22.033-03	2020-08-23 12:45:35.264-03
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, store, "user", comments, created_at, updated_at, payment_type, "deliveryFee", total, subtotal, order_status, delivery) FROM stdin;
\.


--
-- Data for Name: orders__order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders__order_items (id, order_id, "order-item_id") FROM stdin;
1	1	1
2	1	2
3	2	1
4	2	2
5	3	1
6	3	2
7	4	1
8	4	2
12	8	1
13	8	2
14	9	1
15	9	2
16	10	1
17	10	2
\.


--
-- Data for Name: orders_components; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders_components (id, field, "order", component_type, component_id, order_id) FROM stdin;
\.


--
-- Data for Name: payment_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_types (id, name, slug, created_at, updated_at, receive) FROM stdin;
7	Cartão de crédito	cartao-de-credito	2020-08-18 01:10:39.392-03	2020-08-18 01:10:39.392-03	App
9	Dinheiro	dinheiro	2020-08-18 01:11:03.426-03	2020-08-18 01:11:03.426-03	Store
8	PicPay	pic-pay	2020-08-18 01:10:52.119-03	2020-08-18 01:18:53.677-03	App
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, price, category, store, created_at, updated_at, created_by, updated_by) FROM stdin;
3	X Filé	Carne de hambúrguer, frango ao creme ,bacon, calabresa, mussarela, presunto salsicha, ovo, salada, milho, batata palha, maionese molho especial ketchup.	12.40	2	4	2020-07-02 00:34:16.403-03	2020-09-09 01:32:53.871-03	\N	\N
1	Espaguete a Bolonhesa	Espaguete vem com tudo	12.95	6	1	2020-06-25 21:44:01.277-03	2020-09-23 11:49:50.878-03	\N	\N
2	X bacon Egg	X bacon com Egg	9.50	2	1	2020-07-02 00:10:43.265-03	2020-09-23 11:49:50.878-03	\N	\N
\.


--
-- Data for Name: store_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_types (id, name, description, slug, created_at, updated_at) FROM stdin;
1	Bar		bar	2020-06-25 21:40:41.424-03	2020-06-25 21:40:41.424-03
2	Lanchonete	\N	lanche	2020-07-02 02:58:56.471-03	2020-07-02 18:48:32.582-03
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stores (id, name, description, "startTime", "endTime", slug, "deliveryFee", created_at, updated_at, store_type, category, created_by, updated_by) FROM stdin;
4	Burger King	Bom tbm	\N	\N	burger-king	\N	2020-07-07 23:42:20.271-03	2020-09-09 01:32:53.878-03	\N	2	\N	\N
1	Mc Donalds		\N	\N	jhonnys	2.55	2020-06-25 21:42:30.212-03	2020-09-23 11:49:50.886-03	1	2	\N	\N
2	Chopp Time	É o melhor que tá dentdo	\N	\N	mec-lanches	\N	2020-07-02 02:45:31.596-03	2020-09-23 11:55:03.19-03	2	3	\N	\N
\.


--
-- Data for Name: strapi_administrator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strapi_administrator (id, username, email, password, "resetPasswordToken", blocked, firstname, lastname, "registrationToken", "isActive") FROM stdin;
1	murilosandiego.admin	contato@murilosandiego.com.br	$2a$10$J0mTl/xFIY4pVgQLCUYYJeqHJmzNYHd8iUvPkt6Z1QDMwIBbgC702	\N	\N	\N	\N	\N	t
\.


--
-- Data for Name: strapi_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strapi_permission (id, action, subject, fields, conditions, role, created_at, updated_at) FROM stdin;
2	plugins::content-manager.explorer.create	application::category.category	["name", "description", "photo", "slug", "stores"]	[]	2	2020-07-25 11:51:06.755-03	2020-07-25 11:51:06.791-03
1	plugins::content-manager.explorer.create	application::product.product	["name", "description", "price", "photo", "store"]	[]	2	2020-07-25 11:51:06.755-03	2020-07-25 11:51:06.791-03
3	plugins::content-manager.explorer.create	application::store.store	["name", "description", "logo", "cover", "startTime", "endTime", "slug", "deliveryFee", "users", "products", "category"]	[]	2	2020-07-25 11:51:06.756-03	2020-07-25 11:51:06.791-03
4	plugins::content-manager.explorer.read	application::category.category	["name", "description", "photo", "slug", "stores"]	[]	2	2020-07-25 11:51:06.756-03	2020-07-25 11:51:06.792-03
5	plugins::content-manager.explorer.read	application::product.product	["name", "description", "price", "photo", "store"]	[]	2	2020-07-25 11:51:06.756-03	2020-07-25 11:51:06.792-03
6	plugins::content-manager.explorer.read	application::store.store	["name", "description", "logo", "cover", "startTime", "endTime", "slug", "deliveryFee", "users", "products", "category"]	[]	2	2020-07-25 11:51:06.756-03	2020-07-25 11:51:06.792-03
7	plugins::content-manager.explorer.update	application::category.category	["name", "description", "photo", "slug", "stores"]	[]	2	2020-07-25 11:51:06.757-03	2020-07-25 11:51:06.792-03
8	plugins::content-manager.explorer.update	application::product.product	["name", "description", "price", "photo", "store"]	[]	2	2020-07-25 11:51:06.757-03	2020-07-25 11:51:06.792-03
9	plugins::content-manager.explorer.update	application::store.store	["name", "description", "logo", "cover", "startTime", "endTime", "slug", "deliveryFee", "users", "products", "category"]	[]	2	2020-07-25 11:51:06.757-03	2020-07-25 11:51:06.793-03
10	plugins::content-manager.explorer.delete	application::category.category	\N	[]	2	2020-07-25 11:51:06.757-03	2020-07-25 11:51:06.805-03
11	plugins::content-manager.explorer.delete	application::product.product	\N	[]	2	2020-07-25 11:51:06.853-03	2020-07-25 11:51:06.876-03
12	plugins::content-manager.explorer.delete	application::store.store	\N	[]	2	2020-07-25 11:51:06.854-03	2020-07-25 11:51:06.876-03
13	plugins::upload.read	\N	\N	[]	2	2020-07-25 11:51:06.854-03	2020-07-25 11:51:06.876-03
14	plugins::upload.assets.create	\N	\N	[]	2	2020-07-25 11:51:06.854-03	2020-07-25 11:51:06.876-03
15	plugins::upload.assets.update	\N	\N	[]	2	2020-07-25 11:51:06.854-03	2020-07-25 11:51:06.876-03
16	plugins::upload.assets.download	\N	\N	[]	2	2020-07-25 11:51:06.855-03	2020-07-25 11:51:06.877-03
17	plugins::upload.assets.copy-link	\N	\N	[]	2	2020-07-25 11:51:06.855-03	2020-07-25 11:51:06.886-03
18	plugins::content-manager.explorer.create	application::category.category	["name", "description", "photo", "slug", "stores"]	["admin::is-creator"]	3	2020-07-25 11:51:06.934-03	2020-07-25 11:51:06.976-03
19	plugins::content-manager.explorer.create	application::product.product	["name", "description", "price", "photo", "store"]	["admin::is-creator"]	3	2020-07-25 11:51:06.934-03	2020-07-25 11:51:06.977-03
20	plugins::content-manager.explorer.create	application::store.store	["name", "description", "logo", "cover", "startTime", "endTime", "slug", "deliveryFee", "users", "products", "category"]	["admin::is-creator"]	3	2020-07-25 11:51:06.934-03	2020-07-25 11:51:06.977-03
21	plugins::content-manager.explorer.read	application::category.category	["name", "description", "photo", "slug", "stores"]	["admin::is-creator"]	3	2020-07-25 11:51:06.935-03	2020-07-25 11:51:06.977-03
22	plugins::content-manager.explorer.read	application::product.product	["name", "description", "price", "photo", "store"]	["admin::is-creator"]	3	2020-07-25 11:51:06.935-03	2020-07-25 11:51:06.977-03
23	plugins::content-manager.explorer.read	application::store.store	["name", "description", "logo", "cover", "startTime", "endTime", "slug", "deliveryFee", "users", "products", "category"]	["admin::is-creator"]	3	2020-07-25 11:51:06.935-03	2020-07-25 11:51:06.977-03
24	plugins::content-manager.explorer.update	application::category.category	["name", "description", "photo", "slug", "stores"]	["admin::is-creator"]	3	2020-07-25 11:51:06.936-03	2020-07-25 11:51:06.988-03
25	plugins::content-manager.explorer.update	application::product.product	["name", "description", "price", "photo", "store"]	["admin::is-creator"]	3	2020-07-25 11:51:06.936-03	2020-07-25 11:51:06.988-03
26	plugins::content-manager.explorer.update	application::store.store	["name", "description", "logo", "cover", "startTime", "endTime", "slug", "deliveryFee", "users", "products", "category"]	["admin::is-creator"]	3	2020-07-25 11:51:06.936-03	2020-07-25 11:51:06.989-03
27	plugins::content-manager.explorer.delete	application::category.category	\N	["admin::is-creator"]	3	2020-07-25 11:51:06.936-03	2020-07-25 11:51:06.989-03
28	plugins::content-manager.explorer.delete	application::product.product	\N	["admin::is-creator"]	3	2020-07-25 11:51:07.046-03	2020-07-25 11:51:07.071-03
29	plugins::content-manager.explorer.delete	application::store.store	\N	["admin::is-creator"]	3	2020-07-25 11:51:07.049-03	2020-07-25 11:51:07.076-03
30	plugins::upload.read	\N	\N	["admin::is-creator"]	3	2020-07-25 11:51:07.049-03	2020-07-25 11:51:07.076-03
31	plugins::upload.assets.create	\N	\N	[]	3	2020-07-25 11:51:07.049-03	2020-07-25 11:51:07.077-03
32	plugins::upload.assets.update	\N	\N	["admin::is-creator"]	3	2020-07-25 11:51:07.05-03	2020-07-25 11:51:07.077-03
33	plugins::upload.assets.download	\N	\N	[]	3	2020-07-25 11:51:07.05-03	2020-07-25 11:51:07.077-03
34	plugins::upload.assets.copy-link	\N	\N	[]	3	2020-07-25 11:51:07.055-03	2020-07-25 11:51:07.084-03
35	plugins::content-manager.explorer.create	application::category.category	["name", "description", "photo", "slug", "stores"]	[]	1	2020-07-25 11:51:07.154-03	2020-07-25 11:51:07.189-03
36	plugins::content-manager.explorer.create	application::product.product	["name", "description", "price", "photo", "store"]	[]	1	2020-07-25 11:51:07.154-03	2020-07-25 11:51:07.19-03
38	plugins::content-manager.explorer.create	plugins::users-permissions.user	["username", "email", "provider", "password", "resetPasswordToken", "confirmed", "blocked", "role", "store", "name"]	[]	1	2020-07-25 11:51:07.155-03	2020-07-25 11:51:07.19-03
39	plugins::content-manager.explorer.read	application::category.category	["name", "description", "photo", "slug", "stores"]	[]	1	2020-07-25 11:51:07.155-03	2020-07-25 11:51:07.19-03
42	plugins::content-manager.explorer.read	plugins::users-permissions.user	["username", "email", "provider", "password", "resetPasswordToken", "confirmed", "blocked", "role", "store", "name"]	[]	1	2020-07-25 11:51:07.156-03	2020-07-25 11:51:07.191-03
46	plugins::content-manager.explorer.update	plugins::users-permissions.user	["username", "email", "provider", "password", "resetPasswordToken", "confirmed", "blocked", "role", "store", "name"]	[]	1	2020-07-25 11:51:07.266-03	2020-07-25 11:51:07.301-03
55	plugins::upload.read	\N	\N	[]	1	2020-07-25 11:51:07.371-03	2020-07-25 11:51:07.403-03
65	plugins::users-permissions.roles.read	\N	\N	[]	1	2020-07-25 11:51:07.487-03	2020-07-25 11:51:07.522-03
75	admin::marketplace.plugins.install	\N	\N	[]	1	2020-07-25 11:51:07.581-03	2020-07-25 11:51:07.618-03
85	admin::roles.create	\N	\N	[]	1	2020-07-25 11:51:07.679-03	2020-07-25 11:51:07.699-03
43	plugins::content-manager.explorer.update	application::category.category	["name", "description", "photo", "slug", "stores"]	[]	1	2020-07-25 11:51:07.156-03	2020-07-25 11:51:07.191-03
50	plugins::content-manager.explorer.delete	plugins::users-permissions.user	\N	[]	1	2020-07-25 11:51:07.267-03	2020-07-25 11:51:07.308-03
58	plugins::upload.assets.copy-link	\N	\N	[]	1	2020-07-25 11:51:07.372-03	2020-07-25 11:51:07.403-03
69	plugins::users-permissions.providers.update	\N	\N	[]	1	2020-07-25 11:51:07.488-03	2020-07-25 11:51:07.523-03
79	admin::webhooks.update	\N	\N	[]	1	2020-07-25 11:51:07.581-03	2020-07-25 11:51:07.619-03
44	plugins::content-manager.explorer.update	application::product.product	["name", "description", "price", "photo", "store"]	[]	1	2020-07-25 11:51:07.156-03	2020-07-25 11:51:07.202-03
47	plugins::content-manager.explorer.delete	application::category.category	\N	[]	1	2020-07-25 11:51:07.266-03	2020-07-25 11:51:07.307-03
56	plugins::upload.assets.create	\N	\N	[]	1	2020-07-25 11:51:07.371-03	2020-07-25 11:51:07.403-03
68	plugins::users-permissions.providers.read	\N	\N	[]	1	2020-07-25 11:51:07.488-03	2020-07-25 11:51:07.523-03
77	admin::webhooks.read	\N	\N	[]	1	2020-07-25 11:51:07.581-03	2020-07-25 11:51:07.619-03
87	admin::roles.update	\N	\N	[]	1	2020-07-25 11:51:07.679-03	2020-07-25 11:51:07.699-03
37	plugins::content-manager.explorer.create	application::store.store	["name", "description", "logo", "cover", "startTime", "endTime", "slug", "deliveryFee", "users", "products", "category"]	[]	1	2020-07-25 11:51:07.155-03	2020-07-25 11:51:07.19-03
53	plugins::documentation.settings.update	\N	\N	[]	1	2020-07-25 11:51:07.268-03	2020-07-25 11:51:07.308-03
62	plugins::content-manager.collection-types.configure-view	\N	\N	[]	1	2020-07-25 11:51:07.372-03	2020-07-25 11:51:07.404-03
67	plugins::users-permissions.roles.delete	\N	\N	[]	1	2020-07-25 11:51:07.487-03	2020-07-25 11:51:07.522-03
78	admin::webhooks.create	\N	\N	[]	1	2020-07-25 11:51:07.581-03	2020-07-25 11:51:07.619-03
88	admin::roles.delete	\N	\N	[]	1	2020-07-25 11:51:07.68-03	2020-07-25 11:51:07.705-03
40	plugins::content-manager.explorer.read	application::product.product	["name", "description", "price", "photo", "store"]	[]	1	2020-07-25 11:51:07.155-03	2020-07-25 11:51:07.191-03
48	plugins::content-manager.explorer.delete	application::product.product	\N	[]	1	2020-07-25 11:51:07.267-03	2020-07-25 11:51:07.307-03
57	plugins::upload.assets.update	\N	\N	[]	1	2020-07-25 11:51:07.371-03	2020-07-25 11:51:07.403-03
72	plugins::users-permissions.advanced-settings.read	\N	\N	[]	1	2020-07-25 11:51:07.497-03	2020-07-25 11:51:07.532-03
82	admin::users.read	\N	\N	[]	1	2020-07-25 11:51:07.595-03	2020-07-25 11:51:07.634-03
41	plugins::content-manager.explorer.read	application::store.store	["name", "description", "logo", "cover", "startTime", "endTime", "slug", "deliveryFee", "users", "products", "category"]	[]	1	2020-07-25 11:51:07.155-03	2020-07-25 11:51:07.191-03
51	plugins::content-type-builder.read	\N	\N	[]	1	2020-07-25 11:51:07.267-03	2020-07-25 11:51:07.308-03
60	plugins::upload.settings.read	\N	\N	[]	1	2020-07-25 11:51:07.372-03	2020-07-25 11:51:07.404-03
70	plugins::users-permissions.email-templates.read	\N	\N	[]	1	2020-07-25 11:51:07.488-03	2020-07-25 11:51:07.523-03
80	admin::webhooks.delete	\N	\N	[]	1	2020-07-25 11:51:07.582-03	2020-07-25 11:51:07.621-03
45	plugins::content-manager.explorer.update	application::store.store	["name", "description", "logo", "cover", "startTime", "endTime", "slug", "deliveryFee", "users", "products", "category"]	[]	1	2020-07-25 11:51:07.263-03	2020-07-25 11:51:07.309-03
63	plugins::content-manager.components.configure-layout	\N	\N	[]	1	2020-07-25 11:51:07.381-03	2020-07-25 11:51:07.414-03
73	plugins::users-permissions.advanced-settings.update	\N	\N	[]	1	2020-07-25 11:51:07.497-03	2020-07-25 11:51:07.533-03
83	admin::users.update	\N	\N	[]	1	2020-07-25 11:51:07.595-03	2020-07-25 11:51:07.634-03
49	plugins::content-manager.explorer.delete	application::store.store	\N	[]	1	2020-07-25 11:51:07.267-03	2020-07-25 11:51:07.308-03
59	plugins::upload.assets.download	\N	\N	[]	1	2020-07-25 11:51:07.371-03	2020-07-25 11:51:07.403-03
66	plugins::users-permissions.roles.update	\N	\N	[]	1	2020-07-25 11:51:07.487-03	2020-07-25 11:51:07.522-03
76	admin::marketplace.plugins.uninstall	\N	\N	[]	1	2020-07-25 11:51:07.581-03	2020-07-25 11:51:07.618-03
86	admin::roles.read	\N	\N	[]	1	2020-07-25 11:51:07.679-03	2020-07-25 11:51:07.699-03
52	plugins::documentation.read	\N	\N	[]	1	2020-07-25 11:51:07.268-03	2020-07-25 11:51:07.308-03
61	plugins::content-manager.single-types.configure-view	\N	\N	[]	1	2020-07-25 11:51:07.372-03	2020-07-25 11:51:07.404-03
71	plugins::users-permissions.email-templates.update	\N	\N	[]	1	2020-07-25 11:51:07.488-03	2020-07-25 11:51:07.523-03
81	admin::users.create	\N	\N	[]	1	2020-07-25 11:51:07.582-03	2020-07-25 11:51:07.629-03
54	plugins::documentation.settings.regenerate	\N	\N	[]	1	2020-07-25 11:51:07.268-03	2020-07-25 11:51:07.318-03
64	plugins::users-permissions.roles.create	\N	\N	[]	1	2020-07-25 11:51:07.391-03	2020-07-25 11:51:07.423-03
74	admin::marketplace.read	\N	\N	[]	1	2020-07-25 11:51:07.501-03	2020-07-25 11:51:07.537-03
84	admin::users.delete	\N	\N	[]	1	2020-07-25 11:51:07.604-03	2020-07-25 11:51:07.64-03
\.


--
-- Data for Name: strapi_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strapi_role (id, name, code, description, created_at, updated_at) FROM stdin;
1	Super Admin	strapi-super-admin	Super Admins can access and manage all features and settings.	2020-07-25 11:51:06.671-03	2020-07-25 11:51:06.671-03
2	Editor	strapi-editor	Editors can manage and publish contents including those of other users.	2020-07-25 11:51:06.701-03	2020-07-25 11:51:06.701-03
3	Author	strapi-author	Authors can manage and publish the content they created.	2020-07-25 11:51:06.72-03	2020-07-25 11:51:06.72-03
\.


--
-- Data for Name: strapi_users_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strapi_users_roles (id, user_id, role_id) FROM stdin;
1	1	1
\.


--
-- Data for Name: strapi_webhooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strapi_webhooks (id, name, url, headers, events, enabled) FROM stdin;
\.


--
-- Data for Name: upload_file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.upload_file (id, name, "alternativeText", caption, width, height, formats, hash, ext, mime, size, url, "previewUrl", provider, provider_metadata, created_at, updated_at, created_by, updated_by) FROM stdin;
1	19C1-pizza			300	228	{"thumbnail": {"ext": ".webp", "url": "/uploads/thumbnail_19_C1_pizza_9f584377ef.webp", "hash": "thumbnail_19_C1_pizza_9f584377ef", "mime": "image/webp", "path": null, "size": 6.02, "width": 205, "height": 156}}	19_C1_pizza_9f584377ef	.webp	image/webp	10.37	/uploads/19_C1_pizza_9f584377ef.webp	\N	local	\N	2020-06-25 21:27:55.934-03	2020-06-25 21:27:55.934-03	\N	\N
2	19C1-lanches-v2			300	228	{"thumbnail": {"ext": ".webp", "url": "/uploads/thumbnail_19_C1_lanches_v2_acf9ca6651.webp", "hash": "thumbnail_19_C1_lanches_v2_acf9ca6651", "mime": "image/webp", "path": null, "size": 5.92, "width": 205, "height": 156}}	19_C1_lanches_v2_acf9ca6651	.webp	image/webp	9.96	/uploads/19_C1_lanches_v2_acf9ca6651.webp	\N	local	\N	2020-06-25 21:28:31.151-03	2020-06-25 21:28:31.151-03	\N	\N
3	19C1-bebidas			300	228	{"thumbnail": {"ext": ".webp", "url": "/uploads/thumbnail_19_C1_bebidas_50b19e9489.webp", "hash": "thumbnail_19_C1_bebidas_50b19e9489", "mime": "image/webp", "path": null, "size": 4.28, "width": 205, "height": 156}}	19_C1_bebidas_50b19e9489	.webp	image/webp	7.11	/uploads/19_C1_bebidas_50b19e9489.webp	\N	local	\N	2020-06-25 21:28:45.997-03	2020-06-25 21:28:45.997-03	\N	\N
4	19C1-acai			300	228	{"thumbnail": {"ext": ".webp", "url": "/uploads/thumbnail_19_C1_acai_9d589cc19a.webp", "hash": "thumbnail_19_C1_acai_9d589cc19a", "mime": "image/webp", "path": null, "size": 4.8, "width": 205, "height": 156}}	19_C1_acai_9d589cc19a	.webp	image/webp	9.34	/uploads/19_C1_acai_9d589cc19a.webp	\N	local	\N	2020-06-25 21:29:02.319-03	2020-06-25 21:29:02.319-03	\N	\N
5	19C1-doces-e-bolos			300	228	{"thumbnail": {"ext": ".webp", "url": "/uploads/thumbnail_19_C1_doces_e_bolos_b8ef88afc3.webp", "hash": "thumbnail_19_C1_doces_e_bolos_b8ef88afc3", "mime": "image/webp", "path": null, "size": 3, "width": 205, "height": 156}}	19_C1_doces_e_bolos_b8ef88afc3	.webp	image/webp	4.58	/uploads/19_C1_doces_e_bolos_b8ef88afc3.webp	\N	local	\N	2020-06-25 21:29:34.007-03	2020-06-25 21:29:34.007-03	\N	\N
6	adesivo-parede-macarrao-espaguete-massa-italia-adesivo-italia			1200	720	{"large": {"ext": ".jpeg", "url": "/uploads/large_adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061.jpeg", "hash": "large_adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061", "mime": "image/jpeg", "path": null, "size": 83.8, "width": 1000, "height": 600}, "small": {"ext": ".jpeg", "url": "/uploads/small_adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061.jpeg", "hash": "small_adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061", "mime": "image/jpeg", "path": null, "size": 25.9, "width": 500, "height": 300}, "medium": {"ext": ".jpeg", "url": "/uploads/medium_adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061.jpeg", "hash": "medium_adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061", "mime": "image/jpeg", "path": null, "size": 50.75, "width": 750, "height": 450}, "thumbnail": {"ext": ".jpeg", "url": "/uploads/thumbnail_adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061.jpeg", "hash": "thumbnail_adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061", "mime": "image/jpeg", "path": null, "size": 8.44, "width": 245, "height": 147}}	adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061	.jpeg	image/jpeg	120.72	/uploads/adesivo_parede_macarrao_espaguete_massa_italia_adesivo_italia_1a14302061.jpeg	\N	local	\N	2020-06-25 21:36:41.1-03	2020-06-25 21:36:41.1-03	\N	\N
7	92793347_101444031532750_3770048814128300032_o			1080	1080	{"large": {"ext": ".png", "url": "/uploads/large_92793347_101444031532750_3770048814128300032_o_e8c8e37eff.png", "hash": "large_92793347_101444031532750_3770048814128300032_o_e8c8e37eff", "mime": "image/png", "path": null, "size": 50.72, "width": 1000, "height": 1000}, "small": {"ext": ".png", "url": "/uploads/small_92793347_101444031532750_3770048814128300032_o_e8c8e37eff.png", "hash": "small_92793347_101444031532750_3770048814128300032_o_e8c8e37eff", "mime": "image/png", "path": null, "size": 20.59, "width": 500, "height": 500}, "medium": {"ext": ".png", "url": "/uploads/medium_92793347_101444031532750_3770048814128300032_o_e8c8e37eff.png", "hash": "medium_92793347_101444031532750_3770048814128300032_o_e8c8e37eff", "mime": "image/png", "path": null, "size": 34.71, "width": 750, "height": 750}, "thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_92793347_101444031532750_3770048814128300032_o_e8c8e37eff.png", "hash": "thumbnail_92793347_101444031532750_3770048814128300032_o_e8c8e37eff", "mime": "image/png", "path": null, "size": 5.64, "width": 156, "height": 156}}	92793347_101444031532750_3770048814128300032_o_e8c8e37eff	.png	image/png	27.33	/uploads/92793347_101444031532750_3770048814128300032_o_e8c8e37eff.png	\N	local	\N	2020-06-25 21:42:00.558-03	2020-06-25 21:42:00.558-03	\N	\N
8	espaguete-com-molho-a-bolonhesa-ou-ragu-bolognese-1-623x350			623	350	{"small": {"ext": ".jpeg", "url": "/uploads/small_espaguete_com_molho_a_bolonhesa_ou_ragu_bolognese_1_623x350_306a7730f0.jpeg", "hash": "small_espaguete_com_molho_a_bolonhesa_ou_ragu_bolognese_1_623x350_306a7730f0", "mime": "image/jpeg", "path": null, "size": 30.71, "width": 500, "height": 281}, "thumbnail": {"ext": ".jpeg", "url": "/uploads/thumbnail_espaguete_com_molho_a_bolonhesa_ou_ragu_bolognese_1_623x350_306a7730f0.jpeg", "hash": "thumbnail_espaguete_com_molho_a_bolonhesa_ou_ragu_bolognese_1_623x350_306a7730f0", "mime": "image/jpeg", "path": null, "size": 10.36, "width": 245, "height": 138}}	espaguete_com_molho_a_bolonhesa_ou_ragu_bolognese_1_623x350_306a7730f0	.jpeg	image/jpeg	44.01	/uploads/espaguete_com_molho_a_bolonhesa_ou_ragu_bolognese_1_623x350_306a7730f0.jpeg	\N	local	\N	2020-06-25 21:43:52.306-03	2020-06-25 21:43:52.306-03	\N	\N
9	108021_original			4272	2848	{"large": {"ext": ".webp", "url": "/uploads/large_108021_original_77f8340175.webp", "hash": "large_108021_original_77f8340175", "mime": "image/webp", "path": null, "size": 50.64, "width": 1000, "height": 667}, "small": {"ext": ".webp", "url": "/uploads/small_108021_original_77f8340175.webp", "hash": "small_108021_original_77f8340175", "mime": "image/webp", "path": null, "size": 19.35, "width": 500, "height": 333}, "medium": {"ext": ".webp", "url": "/uploads/medium_108021_original_77f8340175.webp", "hash": "medium_108021_original_77f8340175", "mime": "image/webp", "path": null, "size": 35, "width": 750, "height": 500}, "thumbnail": {"ext": ".webp", "url": "/uploads/thumbnail_108021_original_77f8340175.webp", "hash": "thumbnail_108021_original_77f8340175", "mime": "image/webp", "path": null, "size": 6.99, "width": 234, "height": 156}}	108021_original_77f8340175	.webp	image/webp	642.87	/uploads/108021_original_77f8340175.webp	\N	local	\N	2020-06-26 00:28:09.196-03	2020-06-26 00:28:09.196-03	\N	\N
10	X-EGG-BACON			500	400	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_X_EGG_BACON_7ec71716a8.png", "hash": "thumbnail_X_EGG_BACON_7ec71716a8", "mime": "image/png", "path": null, "size": 38.1, "width": 195, "height": 156}}	X_EGG_BACON_7ec71716a8	.png	image/png	224.48	/uploads/X_EGG_BACON_7ec71716a8.png	\N	local	\N	2020-07-02 00:10:39.191-03	2020-07-02 00:10:39.191-03	\N	\N
11	rei-do-bauru-xis-com-fritas			512	340	{"small": {"ext": ".png", "url": "/uploads/small_rei_do_bauru_xis_com_fritas_5d35bbd8f8.png", "hash": "small_rei_do_bauru_xis_com_fritas_5d35bbd8f8", "mime": "image/png", "path": null, "size": 237.34, "width": 500, "height": 332}, "thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_rei_do_bauru_xis_com_fritas_5d35bbd8f8.png", "hash": "thumbnail_rei_do_bauru_xis_com_fritas_5d35bbd8f8", "mime": "image/png", "path": null, "size": 59.04, "width": 235, "height": 156}}	rei_do_bauru_xis_com_fritas_5d35bbd8f8	.png	image/png	246.66	/uploads/rei_do_bauru_xis_com_fritas_5d35bbd8f8.png	\N	local	\N	2020-07-02 00:34:09.311-03	2020-07-02 00:34:09.311-03	\N	\N
12	51464811_1123667514470925_6967202398888525824_n			789	789	{"small": {"ext": ".jpeg", "url": "/uploads/small_51464811_1123667514470925_6967202398888525824_n_b3e1b93b38.jpeg", "hash": "small_51464811_1123667514470925_6967202398888525824_n_b3e1b93b38", "mime": "image/jpeg", "path": null, "size": 8.73, "width": 500, "height": 500}, "medium": {"ext": ".jpeg", "url": "/uploads/medium_51464811_1123667514470925_6967202398888525824_n_b3e1b93b38.jpeg", "hash": "medium_51464811_1123667514470925_6967202398888525824_n_b3e1b93b38", "mime": "image/jpeg", "path": null, "size": 14.35, "width": 750, "height": 750}, "thumbnail": {"ext": ".jpeg", "url": "/uploads/thumbnail_51464811_1123667514470925_6967202398888525824_n_b3e1b93b38.jpeg", "hash": "thumbnail_51464811_1123667514470925_6967202398888525824_n_b3e1b93b38", "mime": "image/jpeg", "path": null, "size": 2.33, "width": 156, "height": 156}}	51464811_1123667514470925_6967202398888525824_n_b3e1b93b38	.jpeg	image/jpeg	13.64	/uploads/51464811_1123667514470925_6967202398888525824_n_b3e1b93b38.jpeg	\N	local	\N	2020-07-02 02:45:26.677-03	2020-07-02 02:45:26.677-03	\N	\N
13	1200px-Logotipo_do_Burger_King.svg			1200	1200	{"large": {"ext": ".png", "url": "/uploads/large_1200px_Logotipo_do_Burger_King_svg_f35fb21857.png", "hash": "large_1200px_Logotipo_do_Burger_King_svg_f35fb21857", "mime": "image/png", "path": null, "size": 249.16, "width": 1000, "height": 1000}, "small": {"ext": ".png", "url": "/uploads/small_1200px_Logotipo_do_Burger_King_svg_f35fb21857.png", "hash": "small_1200px_Logotipo_do_Burger_King_svg_f35fb21857", "mime": "image/png", "path": null, "size": 103.35, "width": 500, "height": 500}, "medium": {"ext": ".png", "url": "/uploads/medium_1200px_Logotipo_do_Burger_King_svg_f35fb21857.png", "hash": "medium_1200px_Logotipo_do_Burger_King_svg_f35fb21857", "mime": "image/png", "path": null, "size": 172.85, "width": 750, "height": 750}, "thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_1200px_Logotipo_do_Burger_King_svg_f35fb21857.png", "hash": "thumbnail_1200px_Logotipo_do_Burger_King_svg_f35fb21857", "mime": "image/png", "path": null, "size": 23.87, "width": 156, "height": 156}}	1200px_Logotipo_do_Burger_King_svg_f35fb21857	.png	image/png	100.06	/uploads/1200px_Logotipo_do_Burger_King_svg_f35fb21857.png	\N	local	\N	2020-07-02 02:56:12.783-03	2020-07-02 02:56:12.783-03	\N	\N
14	23415354_828267307344282_174762494892519924_o			960	541	{"small": {"ext": ".jpeg", "url": "/uploads/small_23415354_828267307344282_174762494892519924_o_f17ff60c16.jpeg", "hash": "small_23415354_828267307344282_174762494892519924_o_f17ff60c16", "mime": "image/jpeg", "path": null, "size": 18.04, "width": 500, "height": 282}, "medium": {"ext": ".jpeg", "url": "/uploads/medium_23415354_828267307344282_174762494892519924_o_f17ff60c16.jpeg", "hash": "medium_23415354_828267307344282_174762494892519924_o_f17ff60c16", "mime": "image/jpeg", "path": null, "size": 32.29, "width": 750, "height": 423}, "thumbnail": {"ext": ".jpeg", "url": "/uploads/thumbnail_23415354_828267307344282_174762494892519924_o_f17ff60c16.jpeg", "hash": "thumbnail_23415354_828267307344282_174762494892519924_o_f17ff60c16", "mime": "image/jpeg", "path": null, "size": 6.1, "width": 245, "height": 138}}	23415354_828267307344282_174762494892519924_o_f17ff60c16	.jpeg	image/jpeg	46.74	/uploads/23415354_828267307344282_174762494892519924_o_f17ff60c16.jpeg	\N	local	\N	2020-07-08 23:44:29.786-03	2020-07-08 23:44:29.786-03	\N	\N
15	favicon-512			512	512	{"small": {"ext": ".png", "url": "/uploads/small_favicon_512_58ba92c4c4.png", "hash": "small_favicon_512_58ba92c4c4", "mime": "image/png", "path": null, "size": 52.62, "width": 500, "height": 500}, "thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_favicon_512_58ba92c4c4.png", "hash": "thumbnail_favicon_512_58ba92c4c4", "mime": "image/png", "path": null, "size": 9.03, "width": 156, "height": 156}}	favicon_512_58ba92c4c4	.png	image/png	39.94	/uploads/favicon_512_58ba92c4c4.png	\N	local	\N	2020-09-23 11:49:41.85-03	2020-09-23 11:49:41.85-03	\N	\N
16	Chopptime-logo-FA49131DFD-seeklogo.com			200	200	\N	Chopptime_logo_FA_49131_DFD_seeklogo_com_f6ad2dd29d	.gif	image/gif	6.27	/uploads/Chopptime_logo_FA_49131_DFD_seeklogo_com_f6ad2dd29d.gif	\N	local	\N	2020-09-23 11:52:16.627-03	2020-09-23 11:52:16.627-03	\N	\N
17	logo_fest			250	172	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_logo_fest_31a76db951.png", "hash": "thumbnail_logo_fest_31a76db951", "mime": "image/png", "path": null, "size": 17.24, "width": 227, "height": 156}}	logo_fest_31a76db951	.png	image/png	7.79	/uploads/logo_fest_31a76db951.png	\N	local	\N	2020-09-23 11:52:50.583-03	2020-09-23 11:52:50.583-03	\N	\N
18	ec6dfe0dc7785984b1c76bac17fe4623			1182	1182	{"large": {"ext": ".jpeg", "url": "/uploads/large_ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89.jpeg", "hash": "large_ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89", "mime": "image/jpeg", "path": null, "size": 38.8, "width": 1000, "height": 1000}, "small": {"ext": ".jpeg", "url": "/uploads/small_ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89.jpeg", "hash": "small_ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89", "mime": "image/jpeg", "path": null, "size": 16.04, "width": 500, "height": 500}, "medium": {"ext": ".jpeg", "url": "/uploads/medium_ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89.jpeg", "hash": "medium_ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89", "mime": "image/jpeg", "path": null, "size": 26.52, "width": 750, "height": 750}, "thumbnail": {"ext": ".jpeg", "url": "/uploads/thumbnail_ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89.jpeg", "hash": "thumbnail_ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89", "mime": "image/jpeg", "path": null, "size": 4.24, "width": 156, "height": 156}}	ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89	.jpeg	image/jpeg	45.85	/uploads/ec6dfe0dc7785984b1c76bac17fe4623_f98fbabb89.jpeg	\N	local	\N	2020-09-23 11:54:59.244-03	2020-09-23 11:54:59.244-03	\N	\N
\.


--
-- Data for Name: upload_file_morph; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.upload_file_morph (id, upload_file_id, related_id, related_type, field, "order") FROM stdin;
1	1	1	categories	photo	1
2	2	2	categories	photo	1
3	3	3	categories	photo	1
4	4	4	categories	photo	1
5	5	5	categories	photo	1
8	8	1	products	photo	1
10	9	6	categories	photo	1
11	10	2	products	photo	1
25	11	3	products	photo	1
27	13	4	stores	logo	1
28	15	1	stores	logo	1
31	18	2	stores	logo	1
32	17	2	stores	cover	1
\.


--
-- Data for Name: users-permissions_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."users-permissions_permission" (id, type, controller, action, enabled, policy, role, created_by, updated_by) FROM stdin;
1	content-manager	components	findcomponent	f		1	\N	\N
2	content-manager	components	findcomponent	f		2	\N	\N
3	content-manager	components	listcomponents	f		1	\N	\N
4	content-manager	components	listcomponents	f		2	\N	\N
5	content-manager	components	updatecomponent	f		1	\N	\N
6	content-manager	components	updatecomponent	f		2	\N	\N
7	content-manager	contentmanager	checkuidavailability	f		1	\N	\N
8	content-manager	contentmanager	checkuidavailability	f		2	\N	\N
9	content-manager	contentmanager	count	f		1	\N	\N
10	content-manager	contentmanager	count	f		2	\N	\N
11	content-manager	contentmanager	create	f		1	\N	\N
12	content-manager	contentmanager	create	f		2	\N	\N
13	content-manager	contentmanager	delete	f		1	\N	\N
14	content-manager	contentmanager	delete	f		2	\N	\N
15	content-manager	contentmanager	deletemany	f		1	\N	\N
16	content-manager	contentmanager	deletemany	f		2	\N	\N
17	content-manager	contentmanager	find	f		1	\N	\N
19	content-manager	contentmanager	findone	f		1	\N	\N
20	content-manager	contentmanager	findone	f		2	\N	\N
18	content-manager	contentmanager	find	f		2	\N	\N
21	content-manager	contentmanager	generateuid	f		1	\N	\N
22	content-manager	contentmanager	generateuid	f		2	\N	\N
23	content-manager	contentmanager	update	f		1	\N	\N
24	content-manager	contentmanager	update	f		2	\N	\N
25	content-manager	contenttypes	findcontenttype	f		1	\N	\N
26	content-manager	contenttypes	findcontenttype	f		2	\N	\N
27	content-manager	contenttypes	listcontenttypes	f		1	\N	\N
28	content-manager	contenttypes	listcontenttypes	f		2	\N	\N
29	content-manager	contenttypes	updatecontenttype	f		1	\N	\N
30	content-manager	contenttypes	updatecontenttype	f		2	\N	\N
31	content-type-builder	builder	getreservednames	f		1	\N	\N
32	content-type-builder	builder	getreservednames	f		2	\N	\N
33	content-type-builder	componentcategories	deletecategory	f		1	\N	\N
36	content-type-builder	componentcategories	editcategory	f		2	\N	\N
34	content-type-builder	componentcategories	deletecategory	f		2	\N	\N
35	content-type-builder	componentcategories	editcategory	f		1	\N	\N
37	content-type-builder	components	createcomponent	f		1	\N	\N
38	content-type-builder	components	createcomponent	f		2	\N	\N
39	content-type-builder	components	deletecomponent	f		1	\N	\N
40	content-type-builder	components	deletecomponent	f		2	\N	\N
41	content-type-builder	components	getcomponent	f		1	\N	\N
42	content-type-builder	components	getcomponent	f		2	\N	\N
43	content-type-builder	components	getcomponents	f		1	\N	\N
45	content-type-builder	components	updatecomponent	f		1	\N	\N
46	content-type-builder	components	updatecomponent	f		2	\N	\N
44	content-type-builder	components	getcomponents	f		2	\N	\N
47	content-type-builder	connections	getconnections	f		1	\N	\N
50	content-type-builder	contenttypes	createcontenttype	f		2	\N	\N
51	content-type-builder	contenttypes	deletecontenttype	f		1	\N	\N
52	content-type-builder	contenttypes	deletecontenttype	f		2	\N	\N
53	content-type-builder	contenttypes	getcontenttype	f		1	\N	\N
54	content-type-builder	contenttypes	getcontenttype	f		2	\N	\N
55	content-type-builder	contenttypes	getcontenttypes	f		1	\N	\N
56	content-type-builder	contenttypes	getcontenttypes	f		2	\N	\N
57	content-type-builder	contenttypes	updatecontenttype	f		1	\N	\N
60	email	email	send	f		2	\N	\N
61	upload	proxy	uploadproxy	f		1	\N	\N
62	upload	proxy	uploadproxy	f		2	\N	\N
64	upload	upload	count	f		2	\N	\N
65	upload	upload	destroy	f		1	\N	\N
63	upload	upload	count	f		1	\N	\N
66	upload	upload	destroy	f		2	\N	\N
67	upload	upload	find	f		1	\N	\N
69	upload	upload	findone	f		1	\N	\N
71	upload	upload	getsettings	f		1	\N	\N
72	upload	upload	getsettings	f		2	\N	\N
73	upload	upload	search	f		1	\N	\N
74	upload	upload	search	f		2	\N	\N
75	upload	upload	updatesettings	f		1	\N	\N
77	upload	upload	upload	f		1	\N	\N
76	upload	upload	updatesettings	f		2	\N	\N
79	users-permissions	auth	callback	f		1	\N	\N
81	users-permissions	auth	connect	t		1	\N	\N
82	users-permissions	auth	connect	t		2	\N	\N
83	users-permissions	auth	emailconfirmation	f		1	\N	\N
84	users-permissions	auth	emailconfirmation	t		2	\N	\N
85	users-permissions	auth	forgotpassword	f		1	\N	\N
86	users-permissions	auth	forgotpassword	t		2	\N	\N
87	users-permissions	auth	register	f		1	\N	\N
90	users-permissions	auth	resetpassword	f		2	\N	\N
155	application	store	update	f		1	\N	\N
91	users-permissions	auth	sendemailconfirmation	f		1	\N	\N
92	users-permissions	auth	sendemailconfirmation	f		2	\N	\N
93	users-permissions	user	count	f		1	\N	\N
95	users-permissions	user	create	f		1	\N	\N
145	application	store	count	t		1	\N	\N
171	application	category	create	f		1	\N	\N
184	application	product	create	f		2	\N	\N
192	application	product	update	f		2	\N	\N
198	application	category	delete	f		3	\N	\N
355	application	order	count	t		1	\N	\N
219	content-type-builder	componentcategories	deletecategory	f		3	\N	\N
229	content-type-builder	contenttypes	updatecontenttype	f		3	\N	\N
235	content-manager	contentmanager	update	f		3	\N	\N
244	content-manager	contenttypes	findcontenttype	f		3	\N	\N
365	application	order	find	f		2	\N	\N
48	content-type-builder	contenttypes	createcontenttype	f		1	\N	\N
58	content-type-builder	contenttypes	updatecontenttype	f		2	\N	\N
78	upload	upload	upload	f		2	\N	\N
88	users-permissions	auth	register	t		2	\N	\N
98	users-permissions	user	destroy	f		2	\N	\N
108	users-permissions	user	update	f		2	\N	\N
118	users-permissions	userspermissions	getemailtemplate	f		2	\N	\N
128	users-permissions	userspermissions	getroles	f		2	\N	\N
138	users-permissions	userspermissions	updateadvancedsettings	f		2	\N	\N
356	application	order	count	f		2	\N	\N
370	application	order	update	f		1	\N	\N
172	application	category	create	f		2	\N	\N
185	application	product	delete	f		1	\N	\N
199	application	product	find	t		3	\N	\N
374	application	order-status	count	f		2	\N	\N
217	content-type-builder	builder	getreservednames	f		3	\N	\N
227	content-type-builder	contenttypes	getcontenttype	f		3	\N	\N
233	content-manager	components	updatecomponent	f		3	\N	\N
243	content-manager	contenttypes	listcontenttypes	f		3	\N	\N
253	users-permissions	user	find	f		3	\N	\N
263	users-permissions	userspermissions	getroutes	f		3	\N	\N
273	users-permissions	userspermissions	index	f		3	\N	\N
283	upload	upload	updatesettings	f		3	\N	\N
290	documentation	documentation	deletedoc	f		2	\N	\N
299	documentation	documentation	login	f		2	\N	\N
309	documentation	documentation	updatesettings	f		3	\N	\N
68	upload	upload	find	f		2	\N	\N
384	application	order-status	find	f		3	\N	\N
347	application	order-item	find	t		2	\N	\N
331	application	payment-type	findone	t		1	\N	\N
319	application	payment-type	count	t		1	\N	\N
146	application	store	count	t		2	\N	\N
338	application	order-item	create	f		3	\N	\N
49	content-type-builder	connections	getconnections	f		2	\N	\N
59	email	email	send	f		1	\N	\N
70	upload	upload	findone	f		2	\N	\N
80	users-permissions	auth	callback	t		2	\N	\N
89	users-permissions	auth	resetpassword	f		1	\N	\N
99	users-permissions	user	destroyall	f		1	\N	\N
110	users-permissions	userspermissions	createrole	f		1	\N	\N
120	users-permissions	userspermissions	getpermissions	f		2	\N	\N
130	users-permissions	userspermissions	getroutes	f		2	\N	\N
140	users-permissions	userspermissions	updateemailtemplate	f		2	\N	\N
147	application	store	create	f		1	\N	\N
156	application	store	update	f		2	\N	\N
357	application	order	count	f		3	\N	\N
173	application	category	delete	f		1	\N	\N
186	application	product	delete	f		2	\N	\N
200	application	product	findone	t		3	\N	\N
371	application	order	update	f		2	\N	\N
220	content-type-builder	components	getcomponents	f		3	\N	\N
230	content-type-builder	contenttypes	deletecontenttype	f		3	\N	\N
240	content-manager	contentmanager	find	f		3	\N	\N
250	users-permissions	auth	register	f		3	\N	\N
260	users-permissions	user	destroyall	f		3	\N	\N
270	users-permissions	userspermissions	updateadvancedsettings	f		3	\N	\N
280	upload	proxy	uploadproxy	f		3	\N	\N
291	documentation	documentation	deletedoc	f		3	\N	\N
300	documentation	documentation	login	f		3	\N	\N
375	application	order-status	count	f		3	\N	\N
385	application	order-status	findone	f		1	\N	\N
350	application	order-item	findone	t		2	\N	\N
321	application	payment-type	count	f		3	\N	\N
332	application	payment-type	findone	t		2	\N	\N
341	application	order-item	create	f		2	\N	\N
94	users-permissions	user	count	f		2	\N	\N
105	users-permissions	user	me	t		1	\N	\N
115	users-permissions	userspermissions	getadvancedsettings	f		1	\N	\N
125	users-permissions	userspermissions	getrole	f		1	\N	\N
144	users-permissions	userspermissions	updaterole	f		2	\N	\N
148	application	store	create	f		2	\N	\N
366	application	order	find	f		3	\N	\N
174	application	category	delete	f		2	\N	\N
358	application	order	create	t		1	\N	\N
194	application	category	findone	t		3	\N	\N
201	application	product	count	t		3	\N	\N
204	application	product	delete	t		3	\N	\N
211	application	store	find	t		3	\N	\N
214	application	store	create	f		3	\N	\N
221	content-type-builder	components	getcomponent	f		3	\N	\N
224	content-type-builder	components	deletecomponent	f		3	\N	\N
231	content-manager	components	listcomponents	f		3	\N	\N
237	content-manager	contentmanager	delete	f		3	\N	\N
241	content-manager	contentmanager	generateuid	f		3	\N	\N
246	users-permissions	auth	callback	f		3	\N	\N
251	users-permissions	auth	emailconfirmation	f		3	\N	\N
256	users-permissions	user	findone	f		3	\N	\N
261	users-permissions	userspermissions	getemailtemplate	f		3	\N	\N
266	users-permissions	userspermissions	getroles	f		3	\N	\N
271	users-permissions	userspermissions	getpermissions	f		3	\N	\N
276	users-permissions	userspermissions	getadvancedsettings	f		3	\N	\N
281	upload	upload	upload	f		3	\N	\N
286	upload	upload	count	f		3	\N	\N
187	application	product	find	t		1	\N	\N
292	documentation	documentation	getinfos	f		1	\N	\N
302	documentation	documentation	loginview	f		2	\N	\N
376	application	order-status	create	f		1	\N	\N
386	application	order-status	findone	f		2	\N	\N
329	application	payment-type	find	t		2	\N	\N
320	application	payment-type	count	t		2	\N	\N
339	application	order-item	create	f		1	\N	\N
337	application	order-item	count	f		1	\N	\N
351	application	order-item	findone	f		3	\N	\N
353	application	order-item	update	f		2	\N	\N
96	users-permissions	user	create	f		2	\N	\N
106	users-permissions	user	me	t		2	\N	\N
116	users-permissions	userspermissions	getadvancedsettings	f		2	\N	\N
126	users-permissions	userspermissions	getrole	f		2	\N	\N
136	users-permissions	userspermissions	searchusers	f		2	\N	\N
149	application	store	delete	f		1	\N	\N
359	application	order	create	f		2	\N	\N
202	application	product	create	t		3	\N	\N
212	application	store	findone	t		3	\N	\N
222	content-type-builder	components	createcomponent	f		3	\N	\N
232	content-manager	components	findcomponent	f		3	\N	\N
242	content-manager	contentmanager	create	f		3	\N	\N
252	users-permissions	auth	sendemailconfirmation	f		3	\N	\N
262	users-permissions	userspermissions	searchusers	f		3	\N	\N
367	application	order	findone	t		1	\N	\N
282	upload	upload	getsettings	f		3	\N	\N
175	application	category	find	t		1	\N	\N
188	application	product	find	t		2	\N	\N
293	documentation	documentation	getinfos	f		2	\N	\N
303	documentation	documentation	loginview	f		3	\N	\N
377	application	order-status	create	f		2	\N	\N
314	users-permissions	userspermissions	deleteprovider	f		2	\N	\N
322	application	payment-type	create	f		1	\N	\N
335	application	payment-type	update	f		2	\N	\N
345	application	order-item	delete	f		2	\N	\N
352	application	order-item	update	f		1	\N	\N
387	application	order-status	findone	f		3	\N	\N
97	users-permissions	user	destroy	f		1	\N	\N
117	users-permissions	userspermissions	getemailtemplate	f		1	\N	\N
127	users-permissions	userspermissions	getroles	f		1	\N	\N
137	users-permissions	userspermissions	updateadvancedsettings	f		1	\N	\N
150	application	store	delete	f		2	\N	\N
360	application	order	create	f		3	\N	\N
378	application	order-status	create	f		3	\N	\N
388	application	order-status	update	f		1	\N	\N
254	users-permissions	user	me	f		3	\N	\N
264	users-permissions	userspermissions	deleterole	f		3	\N	\N
274	users-permissions	userspermissions	createrole	f		3	\N	\N
285	upload	upload	findone	f		3	\N	\N
189	application	product	findone	t		1	\N	\N
107	users-permissions	user	update	t		1	\N	\N
176	application	category	find	t		2	\N	\N
294	documentation	documentation	getinfos	f		3	\N	\N
304	documentation	documentation	regeneratedoc	f		1	\N	\N
313	users-permissions	userspermissions	deleteprovider	f		1	\N	\N
323	application	payment-type	create	f		2	\N	\N
330	application	payment-type	find	f		3	\N	\N
343	application	order-item	count	f		3	\N	\N
100	users-permissions	user	destroyall	f		2	\N	\N
109	users-permissions	userspermissions	createrole	f		2	\N	\N
119	users-permissions	userspermissions	getpermissions	f		1	\N	\N
129	users-permissions	userspermissions	getroutes	f		1	\N	\N
139	users-permissions	userspermissions	updateemailtemplate	f		1	\N	\N
361	application	order	delete	f		1	\N	\N
372	application	order	update	f		3	\N	\N
180	application	category	update	f		2	\N	\N
151	application	store	find	t		1	\N	\N
177	application	category	findone	t		1	\N	\N
379	application	order-status	delete	f		1	\N	\N
190	application	product	findone	t		2	\N	\N
295	documentation	documentation	index	f		1	\N	\N
305	documentation	documentation	regeneratedoc	f		2	\N	\N
315	users-permissions	userspermissions	deleteprovider	f		3	\N	\N
324	application	payment-type	create	f		3	\N	\N
333	application	payment-type	findone	f		3	\N	\N
389	application	order-status	update	f		2	\N	\N
342	application	order-item	find	t		1	\N	\N
101	users-permissions	user	find	f		1	\N	\N
362	application	order	delete	f		2	\N	\N
121	users-permissions	userspermissions	getpolicies	f		1	\N	\N
131	users-permissions	userspermissions	index	f		1	\N	\N
141	users-permissions	userspermissions	updateproviders	f		1	\N	\N
193	application	category	find	t		3	\N	\N
203	application	product	update	t		3	\N	\N
213	application	store	count	f		3	\N	\N
223	content-type-builder	components	updatecomponent	f		3	\N	\N
234	content-manager	contentmanager	checkuidavailability	f		3	\N	\N
249	users-permissions	auth	forgotpassword	f		3	\N	\N
259	users-permissions	user	destroy	f		3	\N	\N
269	users-permissions	userspermissions	updateemailtemplate	f		3	\N	\N
279	email	email	send	f		3	\N	\N
380	application	order-status	delete	f		2	\N	\N
152	application	store	find	t		2	\N	\N
178	application	category	findone	t		2	\N	\N
296	documentation	documentation	index	f		2	\N	\N
306	documentation	documentation	regeneratedoc	f		3	\N	\N
390	application	order-status	update	f		3	\N	\N
316	users-permissions	userspermissions	init	t		1	\N	\N
325	application	payment-type	delete	f		1	\N	\N
334	application	payment-type	update	f		1	\N	\N
340	application	order-item	count	f		2	\N	\N
348	application	order-item	find	f		3	\N	\N
368	application	order	findone	f		2	\N	\N
102	users-permissions	user	find	f		2	\N	\N
363	application	order	delete	f		3	\N	\N
123	users-permissions	userspermissions	getproviders	f		1	\N	\N
381	application	order-status	delete	f		3	\N	\N
143	users-permissions	userspermissions	updaterole	f		1	\N	\N
195	application	category	count	f		3	\N	\N
215	application	store	update	f		3	\N	\N
225	content-type-builder	connections	getconnections	f		3	\N	\N
239	content-manager	contentmanager	count	f		3	\N	\N
248	users-permissions	auth	connect	f		3	\N	\N
258	users-permissions	user	update	f		3	\N	\N
268	users-permissions	userspermissions	getproviders	f		3	\N	\N
278	users-permissions	userspermissions	updaterole	f		3	\N	\N
288	upload	upload	search	f		3	\N	\N
153	application	store	findone	t		1	\N	\N
297	documentation	documentation	index	f		3	\N	\N
307	documentation	documentation	updatesettings	f		1	\N	\N
317	users-permissions	userspermissions	init	t		2	\N	\N
326	application	payment-type	delete	f		2	\N	\N
336	application	payment-type	update	f		3	\N	\N
181	application	product	count	t		1	\N	\N
346	application	order-item	delete	f		3	\N	\N
344	application	order-item	delete	f		1	\N	\N
349	application	order-item	findone	f		1	\N	\N
354	application	order-item	update	f		3	\N	\N
103	users-permissions	user	findone	f		1	\N	\N
113	users-permissions	userspermissions	deleterole	f		1	\N	\N
122	users-permissions	userspermissions	getpolicies	f		2	\N	\N
132	users-permissions	userspermissions	index	f		2	\N	\N
142	users-permissions	userspermissions	updateproviders	f		2	\N	\N
179	application	category	update	f		1	\N	\N
191	application	product	update	f		1	\N	\N
196	application	category	create	f		3	\N	\N
369	application	order	findone	f		3	\N	\N
364	application	order	find	t		1	\N	\N
216	application	store	delete	f		3	\N	\N
226	content-type-builder	contenttypes	getcontenttypes	f		3	\N	\N
238	content-manager	contentmanager	findone	f		3	\N	\N
247	users-permissions	auth	resetpassword	f		3	\N	\N
257	users-permissions	user	create	f		3	\N	\N
267	users-permissions	userspermissions	getrole	f		3	\N	\N
382	application	order-status	find	f		1	\N	\N
287	upload	upload	destroy	f		3	\N	\N
154	application	store	findone	t		2	\N	\N
298	documentation	documentation	login	f		1	\N	\N
308	documentation	documentation	updatesettings	f		2	\N	\N
318	users-permissions	userspermissions	init	t		3	\N	\N
327	application	payment-type	delete	f		3	\N	\N
169	application	category	count	t		1	\N	\N
182	application	product	count	t		2	\N	\N
104	users-permissions	user	findone	f		2	\N	\N
114	users-permissions	userspermissions	deleterole	f		2	\N	\N
124	users-permissions	userspermissions	getproviders	f		2	\N	\N
135	users-permissions	userspermissions	searchusers	f		1	\N	\N
373	application	order-status	count	f		1	\N	\N
383	application	order-status	find	f		2	\N	\N
183	application	product	create	f		1	\N	\N
197	application	category	update	f		3	\N	\N
218	content-type-builder	componentcategories	editcategory	f		3	\N	\N
228	content-type-builder	contenttypes	createcontenttype	f		3	\N	\N
236	content-manager	contentmanager	deletemany	f		3	\N	\N
245	content-manager	contenttypes	updatecontenttype	f		3	\N	\N
255	users-permissions	user	count	f		3	\N	\N
265	users-permissions	userspermissions	getpolicies	f		3	\N	\N
275	users-permissions	userspermissions	updateproviders	f		3	\N	\N
284	upload	upload	find	f		3	\N	\N
289	documentation	documentation	deletedoc	f		1	\N	\N
301	documentation	documentation	loginview	f		1	\N	\N
328	application	payment-type	find	t		1	\N	\N
170	application	category	count	t		2	\N	\N
\.


--
-- Data for Name: users-permissions_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."users-permissions_role" (id, name, description, type, created_by, updated_by) FROM stdin;
3	Admin	Default permission for admin of store	admin	\N	\N
2	Public	Default role given to unauthenticated user.	public	\N	\N
1	Authenticated	Default role given to authenticated user.	authenticated	\N	\N
\.


--
-- Data for Name: users-permissions_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."users-permissions_user" (id, username, email, provider, password, "resetPasswordToken", confirmed, blocked, role, created_at, updated_at, store, name, created_by, updated_by, phone, cpf) FROM stdin;
20	teste	teste@mail.com	local	$2a$10$d5u909umA6whfjrivLdi3.WUKndxOgIQnJP1xT2C3raoElTYp7ysy	\N	t	\N	1	2020-09-23 12:15:43.412-03	2020-09-23 12:17:50.288-03	\N	teste	\N	\N	(99) 99999-9999	175.654.950-85
\.


--
-- Data for Name: users-permissions_user_components; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."users-permissions_user_components" (id, field, "order", component_type, component_id, "users-permissions_user_id") FROM stdin;
19	adresses	1	components_user_addresses	21	20
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 6, true);


--
-- Name: components_user_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.components_user_addresses_id_seq', 21, true);


--
-- Name: core_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_store_id_seq', 44, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 115, true);


--
-- Name: order_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_statuses_id_seq', 6, true);


--
-- Name: orders__order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders__order_items_id_seq', 103, true);


--
-- Name: orders_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_components_id_seq', 2, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 82, true);


--
-- Name: payment_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_types_id_seq', 9, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 3, true);


--
-- Name: store_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_types_id_seq', 2, true);


--
-- Name: stores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stores_id_seq', 4, true);


--
-- Name: strapi_administrator_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.strapi_administrator_id_seq', 1, true);


--
-- Name: strapi_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.strapi_permission_id_seq', 88, true);


--
-- Name: strapi_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.strapi_role_id_seq', 3, true);


--
-- Name: strapi_users_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.strapi_users_roles_id_seq', 1, true);


--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.strapi_webhooks_id_seq', 1, false);


--
-- Name: upload_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.upload_file_id_seq', 18, true);


--
-- Name: upload_file_morph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.upload_file_morph_id_seq', 32, true);


--
-- Name: users-permissions_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."users-permissions_permission_id_seq"', 390, true);


--
-- Name: users-permissions_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."users-permissions_role_id_seq"', 3, true);


--
-- Name: users-permissions_user_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."users-permissions_user_components_id_seq"', 19, true);


--
-- Name: users-permissions_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."users-permissions_user_id_seq"', 20, true);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_unique UNIQUE (slug);


--
-- Name: components_user_addresses components_user_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.components_user_addresses
    ADD CONSTRAINT components_user_addresses_pkey PRIMARY KEY (id);


--
-- Name: core_store core_store_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_store
    ADD CONSTRAINT core_store_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_statuses order_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_statuses
    ADD CONSTRAINT order_statuses_pkey PRIMARY KEY (id);


--
-- Name: order_statuses order_statuses_sequence_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_statuses
    ADD CONSTRAINT order_statuses_sequence_unique UNIQUE (sequence);


--
-- Name: orders__order_items orders__order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders__order_items
    ADD CONSTRAINT orders__order_items_pkey PRIMARY KEY (id);


--
-- Name: orders_components orders_components_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders_components
    ADD CONSTRAINT orders_components_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_types payment_types_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_types
    ADD CONSTRAINT payment_types_name_unique UNIQUE (name);


--
-- Name: payment_types payment_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_types
    ADD CONSTRAINT payment_types_pkey PRIMARY KEY (id);


--
-- Name: payment_types payment_types_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_types
    ADD CONSTRAINT payment_types_slug_unique UNIQUE (slug);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: store_types store_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_types
    ADD CONSTRAINT store_types_pkey PRIMARY KEY (id);


--
-- Name: store_types store_types_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_types
    ADD CONSTRAINT store_types_slug_unique UNIQUE (slug);


--
-- Name: stores stores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_pkey PRIMARY KEY (id);


--
-- Name: stores stores_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_slug_unique UNIQUE (slug);


--
-- Name: strapi_administrator strapi_administrator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_administrator
    ADD CONSTRAINT strapi_administrator_pkey PRIMARY KEY (id);


--
-- Name: strapi_administrator strapi_administrator_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_administrator
    ADD CONSTRAINT strapi_administrator_username_unique UNIQUE (username);


--
-- Name: strapi_permission strapi_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_permission
    ADD CONSTRAINT strapi_permission_pkey PRIMARY KEY (id);


--
-- Name: strapi_role strapi_role_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_role
    ADD CONSTRAINT strapi_role_code_unique UNIQUE (code);


--
-- Name: strapi_role strapi_role_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_role
    ADD CONSTRAINT strapi_role_name_unique UNIQUE (name);


--
-- Name: strapi_role strapi_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_role
    ADD CONSTRAINT strapi_role_pkey PRIMARY KEY (id);


--
-- Name: strapi_users_roles strapi_users_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_users_roles
    ADD CONSTRAINT strapi_users_roles_pkey PRIMARY KEY (id);


--
-- Name: strapi_webhooks strapi_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strapi_webhooks
    ADD CONSTRAINT strapi_webhooks_pkey PRIMARY KEY (id);


--
-- Name: upload_file_morph upload_file_morph_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upload_file_morph
    ADD CONSTRAINT upload_file_morph_pkey PRIMARY KEY (id);


--
-- Name: upload_file upload_file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upload_file
    ADD CONSTRAINT upload_file_pkey PRIMARY KEY (id);


--
-- Name: users-permissions_permission users-permissions_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_permission"
    ADD CONSTRAINT "users-permissions_permission_pkey" PRIMARY KEY (id);


--
-- Name: users-permissions_role users-permissions_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_role"
    ADD CONSTRAINT "users-permissions_role_pkey" PRIMARY KEY (id);


--
-- Name: users-permissions_role users-permissions_role_type_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_role"
    ADD CONSTRAINT "users-permissions_role_type_unique" UNIQUE (type);


--
-- Name: users-permissions_user_components users-permissions_user_components_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_user_components"
    ADD CONSTRAINT "users-permissions_user_components_pkey" PRIMARY KEY (id);


--
-- Name: users-permissions_user users-permissions_user_cpf_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_user"
    ADD CONSTRAINT "users-permissions_user_cpf_unique" UNIQUE (cpf);


--
-- Name: users-permissions_user users-permissions_user_phone_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_user"
    ADD CONSTRAINT "users-permissions_user_phone_unique" UNIQUE (phone);


--
-- Name: users-permissions_user users-permissions_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_user"
    ADD CONSTRAINT "users-permissions_user_pkey" PRIMARY KEY (id);


--
-- Name: users-permissions_user users-permissions_user_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_user"
    ADD CONSTRAINT "users-permissions_user_username_unique" UNIQUE (username);


--
-- Name: orders_components order_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders_components
    ADD CONSTRAINT order_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: users-permissions_user_components users-permissions_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."users-permissions_user_components"
    ADD CONSTRAINT "users-permissions_user_id_fk" FOREIGN KEY ("users-permissions_user_id") REFERENCES public."users-permissions_user"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

